class AppImages {
  static const String homeBanner = 'assets/images/home_banner.jpg';
}