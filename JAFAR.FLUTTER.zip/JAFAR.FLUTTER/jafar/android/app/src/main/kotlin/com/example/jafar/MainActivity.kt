package com.example.jafar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
