import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:walhakni/main.dart'; // تغيير من jafar إلى walhakni

void main() {
  testWidgets('Counter increments smoke test', (WidgetTester tester) async {
    // بناء التطبيق الخاص بك
    await tester.pumpWidget(const MyApp()); // تأكد أن MyApp هو اسم فئتك الرئيسية

    // التحقق من أن العداد يبدأ من 0
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // النقر على زر الزيادة
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    // التحقق من أن العداد زاد
    expect(find.text('0'), findsNothing);
    expect(find.text('1'), findsOneWidget);
  });
}